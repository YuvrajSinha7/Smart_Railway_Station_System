import React from 'react';

export default function HeatmapLegend() {
  return (
    <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-semibold py-3 px-4 glass-panel rounded-b-xl border-t-0">
      <div className="flex items-center gap-1.5">
        <span className="w-3 h-3 rounded-full bg-safe border border-white/20"></span>
        <span>Clear (&lt;40%)</span>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="w-3 h-3 rounded-full bg-warning border border-white/20"></span>
        <span>Busy (40-75%)</span>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="w-3 h-3 rounded-full bg-danger border border-white/20 animate-pulse"></span>
        <span>Congested (&gt;75%)</span>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="w-3 h-3 rounded-full bg-purple-600 border border-white/20"></span>
        <span>Blocked / Emergency</span>
      </div>
    </div>
  );
}
