// Graph of Dhanbad Station Paths
// [Node] -> [{ to: Node, stairs: boolean, distance: number }]
export const STATION_GRAPH = {
  'Main Entrance': [
    { to: 'Ticket Counter', stairs: false, distance: 2 },
    { to: 'Hall A', stairs: false, distance: 3 }
  ],
  'Ticket Counter': [
    { to: 'Hall A', stairs: false, distance: 2 },
    { to: 'Footbridge 1', stairs: true, distance: 4 }
  ],
  'Hall A': [
    { to: 'Platform 1', stairs: false, distance: 3 },
    { to: 'Footbridge 1', stairs: true, distance: 4 },
    { to: 'Hall B', stairs: false, distance: 2 }
  ],
  'Hall B': [
    { to: 'Platform 1', stairs: false, distance: 4 },
    { to: 'Footbridge 2', stairs: true, distance: 4 }
  ],
  'Footbridge 1': [
    { to: 'Platform 2', stairs: true, distance: 3 },
    { to: 'Platform 3', stairs: true, distance: 5 },
    { to: 'Exit A', stairs: true, distance: 6 }
  ],
  'Footbridge 2': [
    { to: 'Platform 2', stairs: true, distance: 3 },
    { to: 'Platform 3', stairs: true, distance: 4 },
    { to: 'Exit B', stairs: true, distance: 5 }
  ],
  'Platform 1': [{ to: 'Exit A', stairs: false, distance: 5 }],
  'Platform 2': [{ to: 'Footbridge 1', stairs: true, distance: 3 }, { to: 'Footbridge 2', stairs: true, distance: 3 }],
  'Platform 3': [{ to: 'Footbridge 1', stairs: true, distance: 5 }, { to: 'Footbridge 2', stairs: true, distance: 4 }],
  'Exit A': [],
  'Exit B': []
};

/**
 * Computes multiple routes and ranks them based on user profile and crowd density
 */
export function calculateBestRoutes(origin, destination, profile, zones, isEvacuation) {
  if (origin === destination) return [];
  
  if (isEvacuation) {
    // In evacuation, hardcode routing to nearest exit bypassing algorithms
    return [{
      path: [origin, 'Least Crowded Exit'],
      score: 100,
      time: 2,
      reason: "Evacuation Mode Override: Directed to nearest safe exit."
    }];
  }

  // Simplified DFS to find all logical paths (max depth 5 to avoid loops)
  const paths = [];
  function dfs(current, currentPath, visited) {
    if (current === destination) {
      paths.push([...currentPath]);
      return;
    }
    if (currentPath.length > 5) return;
    
    const edges = STATION_GRAPH[current] || [];
    for (let edge of edges) {
      if (!visited.has(edge.to)) {
        visited.add(edge.to);
        currentPath.push(edge);
        dfs(edge.to, currentPath, visited);
        currentPath.pop();
        visited.delete(edge.to);
      }
    }
  }
  
  dfs(origin, [], new Set([origin]));

  if (paths.length === 0) {
    return [{ path: ['No valid route found'], score: 0, time: 0, reason: "Destination unreachable." }];
  }

  // Score paths
  const scoredPaths = paths.map(path => {
    let score = 100;
    let time = 0;
    let maxDensity = 0;
    let hasStairs = false;
    let explanationFlags = [];

    path.forEach(step => {
      const nodeDensity = zones[step.to]?.density || 0;
      time += step.distance;
      if (nodeDensity > maxDensity) maxDensity = nodeDensity;
      if (step.stairs) hasStairs = true;

      // Penalize heavily crowded areas
      if (nodeDensity > 75) {
        score -= (nodeDensity - 75) * 2;
      }
    });

    // Profile modifiers
    if (profile === 'Elderly' || profile === 'Luggage') {
      if (hasStairs) {
        score -= 50; 
        explanationFlags.push(`Avoids stairs for ${profile} profile`);
      }
    }
    
    if (profile === 'Hurry') {
      if (maxDensity > 50) {
        score -= maxDensity; 
        explanationFlags.push("Penalizes crowded zones to maintain walking speed");
      }
    }

    let reason = "Optimal balance of distance and current crowd conditions.";
    if (score < 50 && hasStairs && (profile === 'Elderly' || profile === 'Luggage')) {
       reason = "Warning: Includes stairs which conflicts with your profile.";
    } else if (explanationFlags.length > 0) {
       reason = explanationFlags[0];
    } else if (maxDensity > 70) {
       reason = "Shortest route, but expect heavy localized crowds.";
    } else if (hasStairs === false && (profile === 'Elderly' || profile === 'Luggage')) {
       reason = "Selected specifically because it is completely stair-free.";
    }

    // Convert path objects to standard array of names for UI
    const stringPath = [origin, ...path.map(p => p.to)];
    
    // Add real-time mock processing delay per node
    time = time + Math.floor(maxDensity / 20); 

    return {
      path: stringPath,
      score,
      time,
      reason
    };
  });

  // Sort by highest score
  scoredPaths.sort((a, b) => b.score - a.score);
  return scoredPaths.slice(0, 2); // Return top 2 alternatives
}

/**
 * Predicts the best time to arrive based on historical mock modeling
 */
export function getBestTimePrediction() {
  return "Prediction Model suggests arriving between 11:15 AM - 12:00 PM to experience 40% less congestion and faster security checks.";
}
