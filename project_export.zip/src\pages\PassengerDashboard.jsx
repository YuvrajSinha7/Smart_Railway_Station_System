import React, { useState, useEffect } from 'react';
import { useAppContext } from '../store/AppContext';
import StationMap from '../components/Heatmap/StationMap';
import { calculateBestRoutes, getBestTimePrediction } from '../engine/DecisionEngine';
import { MapPin, User, Navigation2, Clock } from 'lucide-react';

export default function PassengerDashboard() {
  const { simulation, userProfile, setUserProfile, origin, setOrigin, destination, setDestination } = useAppContext();
  const [routes, setRoutes] = useState([]);
  
  const locations = Object.keys(simulation.zones);

  useEffect(() => {
    if (origin && destination) {
      const results = calculateBestRoutes(origin, destination, userProfile, simulation.zones, simulation.isEvacuationMode);
      setRoutes(results);
    }
  }, [origin, destination, userProfile, simulation.zones, simulation.isEvacuationMode]);

  return (
    <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* Sidebar - Controls & Information */}
      <div className="space-y-6 lg:col-span-1">
        
        {/* Navigation Form */}
        <div className="glass-panel p-5 rounded-xl">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2"><Navigation2 className="w-5 h-5 text-primary"/> Navigation</h2>
          
          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Your Profile</label>
              <select 
                className="w-full bg-surface border border-white/10 rounded-lg p-2 text-sm focus:ring-1 focus:ring-primary"
                value={userProfile}
                onChange={(e) => setUserProfile(e.target.value)}
              >
                <option value="Normal">Normal Passenger</option>
                <option value="Elderly">Elderly / Reduced Mobility</option>
                <option value="Luggage">With Heavy Luggage</option>
                <option value="Hurry">In a Hurry</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-gray-400 mb-1 block">Current Location</label>
              <select 
                className="w-full bg-surface border border-white/10 rounded-lg p-2 text-sm focus:ring-1 focus:ring-primary"
                value={origin}
                onChange={(e) => setOrigin(e.target.value)}
              >
                {locations.filter(l => !l.startsWith('Exit')).map(l => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs text-gray-400 mb-1 block">Destination</label>
              <select 
                className="w-full bg-surface border border-white/10 rounded-lg p-2 text-sm focus:ring-1 focus:ring-primary"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
              >
                <option value="">-- Select Destination --</option>
                {locations.filter(l => l !== origin).map(l => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Dynamic Route Results */}
        {routes.length > 0 && destination && (
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-gray-300 px-1">Suggested Routes</h3>
            {routes.map((route, i) => (
              <div key={i} className={`glass-panel p-4 rounded-xl border ${i === 0 ? 'border-primary/50 bg-primary/5' : 'border-white/5 opacity-80'}`}>
                <div className="flex justify-between items-center mb-2">
                  <span className={`font-bold ${i === 0 ? 'text-primary' : 'text-gray-300'}`}>Route {i + 1} {i===0 && '(Best)'}</span>
                  <span className="text-xs bg-surface px-2 py-1 rounded-full text-gray-300">~{route.time} mins</span>
                </div>
                
                <div className="relative pl-4 border-l-2 border-gray-700 space-y-3 my-3">
                  {route.path.map((step, idx) => (
                    <div key={idx} className="relative text-sm text-gray-300">
                      <div className="absolute w-2 h-2 bg-gray-500 rounded-full -left-[21px] top-1.5 border-2 border-surface"></div>
                      {step}
                    </div>
                  ))}
                </div>

                <div className="mt-3 text-xs text-yellow-500/90 bg-yellow-500/10 p-2 rounded block">
                   <strong>AI Reason:</strong> {route.reason}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Best Time Predictor */}
        <div className="glass-panel p-5 rounded-xl border border-primary/20 bg-gradient-to-br from-surface to-surface/50">
           <h2 className="text-sm font-bold flex items-center gap-2 text-primary mb-2"><Clock className="w-4 h-4"/> AI Arrival Prediction</h2>
           <p className="text-xs text-gray-300 leading-relaxed">{getBestTimePrediction()}</p>
        </div>

      </div>

      {/* Main Map Area */}
      <div className="lg:col-span-2 h-[600px]">
        <StationMap />
      </div>

    </div>
  );
}
