# Smart Crowd & Experience Management System 🚉

An AI-powered, real-time crowd management and navigation system designed for Dhanbad Railway Station. This system acts as a "Smart Assistant" for both passengers and station authorities, reducing congestion and improving the physical experience of high-density events.

## 🌟 The Problem
Dhanbad Railway Station experiences heavy passenger flow, leading to:
- Severe bottlenecks at footbridges and platforms.
- Passenger anxiety due to unpredictable waiting times.
- Lack of real-time coordination during emergencies.

## 🚀 The Solution (Competitive Advantage)
Unlike traditional static signage and generic public address announcements, this system provides **Proactive, Personalized Intelligence**:
- **Dynamic Routing**: Disperses foot traffic by finding alternate routes based on real-time density.
- **Profile Context**: Suggests routes without stairs for the elderly or passengers with heavy luggage.
- **Explainability**: Doesn't just tell you *where* to go, it tells you *why* (e.g., "Avoids Platform 1 due to heavy localization").

## 🎯 Core Features
1. **Smart Crowd Heatmap & Simulation Engine**: A dynamic UI map powered by a time-based simulation engine that mimics realistic crowd flow and peak/off-peak variances.
2. **Decision Intelligence Engine**: Evaluates paths based on current congestion, physical distance, and user profiles.
3. **Proactive AI Chatbot**: A floating assistant that actively monitors your context and suggests alternatives if a route becomes blocked.
4. **Best Time Predictor**: Analyzes trends to suggest optimal arrival times.
5. **Emergency Evacuation Mode (WOW Feature)**: A one-click admin override that instantly reroutes all system UI to point towards the safest exits, abandoning standard logic.

## 🛠 Tech Stack (< 1 MB Bundle Size)
- **Frontend**: React.js (Vite configuration)
- **Styling**: Tailwind CSS v3 (Custom Utility classes, Glassmorphism design)
- **State/Logic**: React Hooks & Context API (Zero heavy external charting/state libraries)
- **Icons**: Lucide-React
- **Database / AI**: Simulated natively in React for rapid, local, offline-capable demos.

## 📦 Setup Instructions

1. **Prerequisites**: Ensure you have Node.js and NPM installed.
2. **Installation**:
   ```bash
   npm install
   ```
3. **Run Local Server**:
   ```bash
   npm run dev
   ```
4. **Build for Production**:
   ```bash
   npm run build
   ```

## 🌐 Google Services Integration & Scalability
This project structure is explicitly built to be deployed to **Firebase Hosting**. 
- To scale this simulation into reality, `SimulationEngine.js` is built as an abstraction layer. The `setInterval` mock can be swapped out with a **Firebase Firestore `onSnapshot`** listener that consumes live data fed by station CCTVs or Google Maps foot-traffic APIs.

## 🧪 Demo Flow Walkthrough

1. **Dashboard Entry**: Arrive at the Passenger dashboard. Notice the "Live System Active" indicator and the abstract heatmap breathing with live data.
2. **Routing**: Select "With Heavy Luggage" and destination "Exit A". Observe the Decision Engine bypassing Footbridge 1 because of stairs. Read the AI Reason below the route.
3. **Alerts & Chat**: Wait 15 seconds. If a platform spikes to >85% density, an alert banner will drop. Click the Chatbot in the bottom right, and it will proactively suggest avoiding the crowded zone.
4. **Admin Escalation**: Navigate to the Admin Dashboard (top right). Click **Trigger Evacuation Mode**. Return to the Map/Passenger view to see the UI locked instantly into secure exit routing.

## 📝 Assumptions & Constraints
- Map distances are abstract unit measurements.
- For the demo, crowd data is generated using a realistic mathematical distribution variance mapped to time-of-day multipliers.

---
*Built as a concept solution for improving high-density real-world logistics.*
